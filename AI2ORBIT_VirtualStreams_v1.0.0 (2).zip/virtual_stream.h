#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "tunnel_manager.h"
#include "port_switcher.h"
#include "logger.h"

namespace netswitch {

enum class StreamGroup {
    SYSTEM,
    APPLICATION
};

enum class StreamProtocol {
    TCP,
    UDP,
    TLS_TCP
};

enum class StreamSecurityMode {
    EPHEMERAL,
    PERSISTENT,
    TUNNEL_VPN
};

struct StreamConfig {
    int stream_id;
    StreamGroup group;
    StreamProtocol protocol;
    StreamSecurityMode security_mode;
    std::string bind_address;
    uint16_t bind_port;
    std::string remote_host;
    uint16_t remote_port;
    int socket_timeout_ms;
    int max_retries;
    bool tcp_nodelay;
    bool so_keepalive;
    int keepalive_interval_sec;
    int linger_timeout_sec;
    std::string tunnel_id;
};

struct StreamTransfer {
    int stream_id;
    uint64_t transfer_id;
    size_t bytes_sent;
    size_t bytes_received;
    double elapsed_ms;
    bool success;
    std::string error;
    int socket_opens;
    int socket_closes;
};

struct StreamStats {
    int stream_id;
    uint64_t total_transfers;
    uint64_t successful_transfers;
    uint64_t failed_transfers;
    uint64_t total_bytes_sent;
    uint64_t total_bytes_received;
    uint64_t total_socket_opens;
    uint64_t total_socket_closes;
    double avg_transfer_ms;
    double min_transfer_ms;
    double max_transfer_ms;
    std::chrono::steady_clock::time_point created_at;
    std::chrono::steady_clock::time_point last_transfer_at;
};

using StreamDataCallback = std::function<void(int stream_id, const uint8_t* data, size_t len)>;
using StreamEventCallback = std::function<void(int stream_id, const std::string& event, const std::string& detail)>;

class VirtualStream {
public:
    VirtualStream(WinsockEngine& engine, Logger& logger);
    ~VirtualStream();

    bool open_stream(const StreamConfig& config);
    bool close_stream(int stream_id);
    bool is_stream_open(int stream_id) const;

    StreamTransfer send(int stream_id, const void* data, size_t len);
    StreamTransfer send_with_response(int stream_id, const void* data, size_t len,
                                      void* response_buf, size_t response_max, size_t& response_len);

    bool listen_stream(int stream_id, StreamDataCallback on_data);
    bool stop_listening(int stream_id);

    StreamConfig get_config(int stream_id) const;
    StreamStats get_stats(int stream_id) const;
    std::vector<int> get_open_streams() const;
    std::vector<int> get_system_streams() const;
    std::vector<int> get_application_streams() const;

    void set_tunnel_manager(TunnelManager* tm) { tunnel_mgr_ = tm; }
    void set_port_switcher(PortSwitcher* ps) { port_switcher_ = ps; }
    void on_event(StreamEventCallback cb) { event_callback_ = cb; }

    static StreamConfig make_system_stream(int id, const std::string& host, uint16_t port);
    static StreamConfig make_app_stream(int id, const std::string& host, uint16_t port);
    static StreamConfig make_vpn_stream(int id, const std::string& host, uint16_t port,
                                        const std::string& tunnel_id);

    static constexpr int SYSTEM_STREAM_MIN = 1;
    static constexpr int SYSTEM_STREAM_MAX = 6;
    static constexpr int APP_STREAM_MIN = 7;
    static constexpr int APP_STREAM_MAX = 65535;

private:
    WinsockEngine& engine_;
    Logger& logger_;
    TunnelManager* tunnel_mgr_ = nullptr;
    PortSwitcher* port_switcher_ = nullptr;
    StreamEventCallback event_callback_;

    struct StreamEntry {
        StreamConfig config;
        StreamStats stats;
        std::atomic<bool> listening{false};
        std::thread listener_thread;
        SOCKET listener_socket = INVALID_SOCKET;
        std::mutex send_mutex;
    };

    mutable std::mutex mutex_;
    std::map<int, std::unique_ptr<StreamEntry>> streams_;
    std::atomic<uint64_t> next_transfer_id_{1};

    SOCKET ephemeral_connect(const StreamConfig& config);
    void ephemeral_disconnect(SOCKET sock, const StreamConfig& config);
    SOCKET tunnel_connect(const StreamConfig& config);
    int send_all(SOCKET sock, const void* data, size_t len, int timeout_ms);
    int recv_all(SOCKET sock, void* buf, size_t len, int timeout_ms);
    void emit_event(int stream_id, const std::string& event, const std::string& detail);
    void listener_worker(int stream_id, StreamDataCallback callback);
    bool validate_stream_id(int id, StreamGroup group) const;
    void update_stats(StreamEntry& entry, const StreamTransfer& transfer);
};

class VirtualStreamPipe {
public:
    VirtualStreamPipe(VirtualStream& vs, int from_stream, int to_stream, Logger& logger);
    ~VirtualStreamPipe();

    bool start();
    bool stop();
    bool is_running() const { return running_.load(); }

    struct PipeStats {
        uint64_t messages_forwarded;
        uint64_t bytes_forwarded;
        uint64_t errors;
        double avg_latency_ms;
    };
    PipeStats get_stats() const { return stats_; }

private:
    VirtualStream& vs_;
    int from_stream_;
    int to_stream_;
    Logger& logger_;
    std::atomic<bool> running_{false};
    std::thread pipe_thread_;
    PipeStats stats_ = {};

    void pipe_worker();
};

} // namespace netswitch
